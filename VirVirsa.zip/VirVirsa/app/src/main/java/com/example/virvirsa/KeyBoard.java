package com.example.virvirsa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubeIntents;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

public class KeyBoard extends YouTubeBaseActivity {
    ImageButton btn_mic;
    EditText editTextOfKeyBoard;
    String senderMsg;
    ProgressBar progressBarK;
    YouTubePlayerView youTubeview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_key_board);
        progressBarK=findViewById(R.id.materialProgressBarofKey);
        btn_mic = findViewById(R.id.button_mic);

        editTextOfKeyBoard = findViewById(R.id.EditTextView_ofKey);

        btn_mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "MIC PRESSED", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(KeyBoard.this, MainActivity.class));
            }
        });

        youTubeview=(YouTubePlayerView)findViewById(R.id.YT);

        YouTubePlayer.OnInitializedListener onInitializedListener;

//        startActivity(YouTubeIntents.createSearchIntent(getApplicationContext(),"alone"));



        
    }
    public void BtnClicked(View view){
        EditText editTextss=findViewById(R.id.EditTextView_ofKey);
        progressBarK.setVisibility(View.VISIBLE);
        senderMsg=editTextss.getText().toString();

        Toast.makeText(getApplicationContext(), editTextss.getText().toString(), Toast.LENGTH_SHORT).show();

    }
}