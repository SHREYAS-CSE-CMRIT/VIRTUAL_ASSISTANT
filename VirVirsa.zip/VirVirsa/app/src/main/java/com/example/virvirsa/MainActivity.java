package com.example.virvirsa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.Manifest;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.ContactsContract;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.github.ybq.android.spinkit.sprite.Sprite;
import com.github.ybq.android.spinkit.style.DoubleBounce;
import com.github.ybq.android.spinkit.style.Wave;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubeIntents;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.type.Date;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends YouTubeBaseActivity {
    public int stats=0;
    public static final Integer RecordAudioRequestCode = 1;
    private SpeechRecognizer speechRecognizer;
    TextView inputtext,displayAnswer;
    ImageView imageViewOfMIC,extraEditSendBTN,timePickerIMG;
    ProgressBar progressBar,progressBar1;

    TimePickerDialog timePickerDialog;
    Calendar calendar;
    int currentHour,currentMinute;

    ArrayList<Android_Contact> arrayList_Android_Contacts = new ArrayList<Android_Contact>();

    com.google.android.material.textfield.TextInputLayout extraText1,extraText2,extraText3;
    String res;

    private TextToSpeech mTTS;

    EditText extraEdit1,extraEdit2,extraEdit3;

    RelativeLayout webScreen;
    RelativeLayout.LayoutParams params;
    WebView wv1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inputtext=findViewById(R.id.default_text);
        imageViewOfMIC=findViewById(R.id.Mic_off);
        displayAnswer=findViewById(R.id.displayAnswer);
        wv1=findViewById(R.id.webView);

        extraText1=findViewById(R.id.ENTERip);
        extraText2=findViewById(R.id.ENTERip2);
        extraText3=findViewById(R.id.ENTERip3);
        extraEdit1=findViewById(R.id.takeIp);
        extraEdit2=findViewById(R.id.takeIp2);
        extraEdit3=findViewById(R.id.takeIp3);
        extraEditSendBTN=findViewById(R.id.mainsender);
        timePickerIMG=findViewById(R.id.timePicker);
//        webScreen=findViewById(R.id.webScreen);

        webScreen=findViewById(R.id.webScreen);
        params= (RelativeLayout.LayoutParams) webScreen.getLayoutParams();



        if(ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED){
            checkPermission();
        }


        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);


        progressBar=findViewById(R.id.spin_kit);
        Sprite Wave=new Wave();
        progressBar.setIndeterminateDrawable(Wave);

        progressBar1=findViewById(R.id.materialProgressBar);




            inputtext.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this,KeyBoard.class));

                }
            });


        imageViewOfMIC.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    displayAnswer.setText("");
                    vibrator.vibrate(100);
                    imageViewOfMIC.setImageResource(R.drawable.ic_baseline_mic_24);
                    wv1.setVisibility(View.GONE);
                    params.height=825;
                    progressBar.setIndeterminateDrawable(Wave);
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar1.setVisibility(View.VISIBLE);

                    VoiceToText();




                }
            });




        Cursor cursor_Android_Contacts = null;
        ContentResolver contentResolver = getContentResolver();

        try {
            cursor_Android_Contacts = contentResolver.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        } catch (Exception ex) {

            Toast.makeText(getApplicationContext(), ex.getMessage(), Toast.LENGTH_SHORT).show();
        }


        if (cursor_Android_Contacts.getCount() > 0) {
//----< has Contacts >----
//----< @Loop: all Contacts >----
            while (cursor_Android_Contacts.moveToNext()) {
//< init >
                Android_Contact android_contact = new Android_Contact();
                String contact_id = cursor_Android_Contacts.getString(cursor_Android_Contacts.getColumnIndex(ContactsContract.Contacts._ID));
                String contact_display_name = cursor_Android_Contacts.getString(cursor_Android_Contacts.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
//</ init >

//----< set >----
                android_contact.android_contact_Name = contact_display_name;


//----< get phone number >----
                int hasPhoneNumber = Integer.parseInt(cursor_Android_Contacts.getString(cursor_Android_Contacts.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)));
                if (hasPhoneNumber > 0) {

                    Cursor phoneCursor = contentResolver.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                            , null
                            , ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?"
                            , new String[]{contact_id}
                            , null);

                    while (phoneCursor.moveToNext()) {
                        String phoneNumber = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
//< set >
                        android_contact.android_contact_TelefonNr = phoneNumber;
//</ set >
                    }
                    phoneCursor.close();
                }
//----</ set >----
//----</ get phone number >----

// Add the contact to the ArrayList
                arrayList_Android_Contacts.add(android_contact);
            }

        }else Toast.makeText(getApplicationContext(), "CAT", Toast.LENGTH_SHORT).show();

        //----------------------------------done getting contacts----------




    }





    public void VoiceToText(){


        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(MainActivity.this);
        final Intent speechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle bundle) {

            }

            @SuppressLint("ResourceAsColor")
            @Override
            public void onBeginningOfSpeech() {
                inputtext.setText("");
                inputtext.setTextColor(R.color.black);
                inputtext.setHintTextColor(R.color.green);
                inputtext.setHint("Listening...");
            }

            @Override
            public void onRmsChanged(float v) {

            }

            @Override
            public void onBufferReceived(byte[] bytes) {

            }

            @Override
            public void onEndOfSpeech() {

            }

            @SuppressLint("ResourceType")
            @Override
            public void onError(int i) {
//                Toast.makeText(getApplicationContext(), "OnError", Toast.LENGTH_SHORT).show();
                inputtext.setTextColor(R.color.reads);
                inputtext.setText("Sorry Try Again");
                inputtext.setTextColor(R.color.black);
                speechRecognizer.stopListening();
                speechRecognizer.destroy();
                imageViewOfMIC.setImageResource(R.drawable.ic_baseline_mic_off_24);

                progressBar.setVisibility(View.INVISIBLE);
                progressBar1.setVisibility(View.INVISIBLE);

            }

            @Override
            public void onResults(Bundle bundle) {
                imageViewOfMIC.setImageResource(R.drawable.ic_baseline_mic_off_24);
                ArrayList<String> data = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                inputtext.setText(data.get(0));
                progressBar.setVisibility(View.INVISIBLE);
                progressBar1.setVisibility(View.INVISIBLE);
                calculate();
                texttospeech();
            }

            @Override
            public void onPartialResults(Bundle bundle) {
                Toast.makeText(getApplicationContext(), "Partial Result", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onEvent(int i, Bundle bundle) {

            }
        });
        speechRecognizer.startListening(speechRecognizerIntent);

    }



    private void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.RECORD_AUDIO},RecordAudioRequestCode);
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_CONTACTS},1);
        }

    }



    public void calculate(){    //----------------------------------------logic----------------------
        displayAnswer.setVisibility(View.VISIBLE);
        String uu=inputtext.getText().toString();
        String check=calculate2(uu);
        switch (check){
            case "there":displayAnswer.setText(res);
                            break;

            case "wiki":    displayAnswer.setText("This is what i found on wikipedia");
                                webScreen=findViewById(R.id.webScreen);
                                RelativeLayout.LayoutParams params= (RelativeLayout.LayoutParams) webScreen.getLayoutParams();
                                params.height=1600;
                                wv1.setVisibility(View.VISIBLE);
                                webScreen.setLayoutParams(params);
                                wv1.getSettings().setJavaScriptEnabled(true);
                                wv1.getSettings().supportZoom();
                                wv1.loadUrl("https://en.wikipedia.org/wiki/"+uu);
                                wv1.setWebViewClient(new WebViewClient());

        }


    }                           //-----------------------------------logic----------------------------

    private String  calculate2(String uu) {
        String temp=uu.toLowerCase();
        uu=uu.toLowerCase();
        if(uu.contains("hello")||uu.contains("greetings")||uu.contains("greet")){
            res="Welcome,How may i help you?";
            return "there";
        }else if(uu.contains("what can you do?")||uu.contains("you do")||uu.contains("can you do"))
        {
            res="I can make you a call, maybe create/add a contact, set an alarm or Send an Email";
            return "there";
        }else if(uu.contains("i am fine")||uu.contains("fine")||uu.contains("ok")){
            res="Glad to hear that.";
            return "there";
        }else if (uu.contains("date")||uu.contains("time")||uu.contains("day")){
            java.util.Date date=new java.util.Date();
            String t=date.toString();
            String day=t.substring(0,3)+"day";
            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
            res="its "+day +" "+sdf.format(date);
            return "there";
        }else if(uu.contains("repeat")||uu.contains("repeat again")||uu.contains("again")){
            return "there";
        }else if (uu.equals("open youtube")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.google.android.youtube");
            if (launchIntent != null) {
                res="opening youtube";
                startActivity(launchIntent);//null pointer check in case package name was not found

            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("send email")||uu.contains("create email")){
            stats=0;
            params.height=1600;
            webScreen.setLayoutParams(params);
            extraText1.setVisibility(View.VISIBLE) ;
            extraText1.setHint("BODY");
            extraText2.setVisibility(View.VISIBLE) ;
            extraText2.setHint("SUBJECT");
            extraText3.setVisibility(View.VISIBLE) ;
            extraText3.setHint("TO..");
            extraEdit1.setVisibility(View.VISIBLE);
            extraEdit2.setVisibility(View.VISIBLE);
            extraEdit2.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_SUBJECT);
            extraEdit3.setVisibility(View.VISIBLE);
            extraEdit3.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
            extraEditSendBTN.setVisibility(View.VISIBLE);

            res="Type the details above";
            texttospeech();

            return "there";
        }else if(uu.contains("add contact")||uu.contains("create contact")){
            stats=1;
            params.height=1600;
            extraText1.setVisibility(View.VISIBLE) ;
            extraText1.setHint("Phone No:");
            extraText2.setVisibility(View.VISIBLE) ;
            extraText2.setHint("EMAIL:");
            extraText3.setVisibility(View.VISIBLE) ;
            extraText3.setHint("NAME:");
            extraEdit1.setVisibility(View.VISIBLE);
            extraEdit1.setInputType(InputType.TYPE_CLASS_PHONE);
            extraEdit2.setVisibility(View.VISIBLE);
            extraEdit2.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
            extraEdit3.setVisibility(View.VISIBLE);
            extraEditSendBTN.setVisibility(View.VISIBLE);
            res="fill the Contact Details";
            texttospeech();
            return "there";
        }  else if (uu.contains("alarm")){
            stats=2;
            params.height=1300;
            timePickerIMG.setVisibility(View.VISIBLE);
            extraText1.setVisibility(View.VISIBLE) ;
            extraText1.setHint("minute:");
            extraText2.setVisibility(View.VISIBLE) ;
            extraText2.setHint("Hour:");
            extraEdit1.setVisibility(View.VISIBLE);
            extraEdit1.setInputType(InputType.TYPE_CLASS_NUMBER);
            extraEdit2.setVisibility(View.VISIBLE);
            extraEdit2.setInputType(InputType.TYPE_CLASS_NUMBER);
            extraEditSendBTN.setVisibility(View.VISIBLE);
            res="Fill the Time in box or click on Time Picker Icon to set the Time";
            texttospeech();
            return "there";
        }   else if (uu.contains("event")){
            stats=3;
            params.height=1600;
            extraText1.setVisibility(View.VISIBLE) ;
            extraText1.setHint("Location:");
            extraText2.setVisibility(View.VISIBLE) ;
            extraText2.setHint("Description:");
            extraText3.setVisibility(View.VISIBLE) ;
            extraText3.setHint("Tittle:");
            extraEdit1.setVisibility(View.VISIBLE);
            extraEdit2.setVisibility(View.VISIBLE);
            extraEdit3.setVisibility(View.VISIBLE);
            extraEditSendBTN.setVisibility(View.VISIBLE);
            res="Fill the details";
            texttospeech();
            return "there";
        }else if (uu.equals("open whatsapp")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
            if (launchIntent != null) {
                res="opening Whatsapp";
                startActivity(launchIntent);//null pointer check in case package name was not found

            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }
        else if(uu.contains("call")){
            String name=inputtext.getText().toString().toLowerCase();
            String No;
            if (name.equals("call")){
                name="";
                res="say a name";
            }
            else {name=name.substring(5,name.length());
                name.toLowerCase();
                }

            if (name.isEmpty())
                Toast.makeText(getApplicationContext(), "Contact not Saved", Toast.LENGTH_SHORT).show();
            else {

                name.toLowerCase();
                String bk="notFound";
                for(int i=0;i<arrayList_Android_Contacts.size();i++){
                    String ttt=arrayList_Android_Contacts.get(i).android_contact_Name.toLowerCase();
                    String wrongSpell=name.substring(0,4);
                    String wrong1=name.substring((name.length()-4) ,name.length());
                    if (ttt.contains(name)|| ttt.contains(wrongSpell)){
                        Toast.makeText(getApplicationContext(), "Found: "+arrayList_Android_Contacts.get(i).android_contact_Name, Toast.LENGTH_SHORT).show();
                        res="Calling "+arrayList_Android_Contacts.get(i).android_contact_Name.toString();
                        texttospeech();
                        bk="Found";
                        No=arrayList_Android_Contacts.get(i).android_contact_TelefonNr;
                        Intent intent = new Intent(Intent.ACTION_DIAL);
                        intent.setData(Uri.parse("tel:"+No));

                        startActivity(intent);
                    }else{
                        }


                    if (bk.equals("notFound")){
                        res="Please make sure the Name is proper and Contact is Saved";
                    }

                }

            }
            //--------------------------accessing contacts-------



//            Toast.makeText(getApplicationContext() , "name:- "+name, Toast.LENGTH_SHORT).show();
            return "there";
        }else if (uu.contains("pubg")||uu.contains("battle ground mobile india")||uu.contains("bgmi")){
            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.pubg.imobile");
            if (launchIntent != null) {
                res="opening BGMI";
                startActivity(launchIntent);//null pointer check in case package name was not found

            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("calculator")||uu.contains("calci")||uu.contains("calculate")){
            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.miui.calculator");
            if (launchIntent != null) {
                res="opening Calculator";
                startActivity(launchIntent);//null pointer check in case package name was not found

            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("calendar")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.xiaomi.calendar");
            if (launchIntent != null) {
                res="opening Calendar";
                texttospeech();
                startActivity(launchIntent);//null pointer check in case package name was not found

            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("camera")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.android.camera");
            if (launchIntent != null) {
                res="opening Camera";
                startActivity(launchIntent);//null pointer check in case package name was not found
                res="";
            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("chrome")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.android.chrome");
            if (launchIntent != null) {
                res="opening Chrome";
                startActivity(launchIntent);//null pointer check in case package name was not found
                res="";
            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("open contacts")||uu.contains("open contact")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.android.contacts");
            if (launchIntent != null) {
                res="opening contacts";
                startActivity(launchIntent);//null pointer check in case package name was not found
                res="";
            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("instagram")||uu.contains("instagram")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.instagram.android");
            if (launchIntent != null) {
                res="opening Instagram";
                startActivity(launchIntent);//null pointer check in case package name was not found
                res="";
            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("flipkart")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.flipkart.android");
            if (launchIntent != null) {
                res="opening flipkart";
                startActivity(launchIntent);//null pointer check in case package name was not found
                res="";
            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("gallery")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.miui.gallery");
            if (launchIntent != null) {
                res="opening gallery";
                startActivity(launchIntent);//null pointer check in case package name was not found
                res="";
            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("gmail")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.google.android.gm");
            if (launchIntent != null) {
                res="opening gmail";
                startActivity(launchIntent);//null pointer check in case package name was not found
                res="";
            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("google")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.google.android.googlequicksearchbox");
            if (launchIntent != null) {
                res="opening google";
                startActivity(launchIntent);//null pointer check in case package name was not found
                res="";
            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("powerpoint")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.microsoft.office.powerpoint");
            if (launchIntent != null) {
                res="opening PowerPoint";
                startActivity(launchIntent);//null pointer check in case package name was not found
                res="";
            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }else if (uu.contains("twitter")){

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.twitter.android");
            if (launchIntent != null) {
                res="opening twitter";
                startActivity(launchIntent);//null pointer check in case package name was not found
                res="";
            }else Toast.makeText(getApplicationContext(), "No apps Found", Toast.LENGTH_SHORT).show();

            return "there";
        }

        else if (uu.contains("whatsapp")||uu.contains("send message")||uu.contains("send whatsapp message")){
            stats=4;

            res="please type the message";
            params.height=1300;
            extraEdit1.setVisibility(View.VISIBLE);
            extraText1.setVisibility(View.VISIBLE);
            extraText1.setHint("MSG: ");
            extraEditSendBTN.setVisibility(View.VISIBLE);

            return "there";
        }

        else if(uu.contains("play")||uu.contains("youtube")){

            String plaa=inputtext.getText().toString();
            res="Please select which Video to play!..";
            startActivity(YouTubeIntents.createSearchIntent(getApplicationContext(),plaa));

            return "there";
        }else if(uu.contains("maps")||uu.contains("near me")){



            Uri gmmIntentUri = Uri.parse("geo:0,0?q="+uu);
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");
            if (mapIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(mapIntent);
            }

            return "there";
        }
            else
            return "wiki";
    }




    public void texttospeech(){
        mTTS=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status==TextToSpeech.SUCCESS){
                    int result=mTTS.setLanguage(Locale.US);
                    if (result==TextToSpeech.LANG_MISSING_DATA
                            || result==TextToSpeech.LANG_NOT_SUPPORTED){
                       // Toast.makeText(getApplicationContext(), "Language Not Supported", Toast.LENGTH_SHORT).show();
                    }else {
                        speakOut();
                    }
                }else {
                    Toast.makeText(getApplicationContext(), "Initilization Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }




    private void speakOut() {
        String text = displayAnswer.getText().toString();
        if(text == null || text.isEmpty())
            return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            String utteranceId=this.hashCode() + "";

            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId);
        } else {
            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }
    }



    @Override
    protected void onDestroy() {
        if(mTTS != null){
            mTTS.stop();
            mTTS.shutdown();
        }
        super.onDestroy();
    }


    public void intentSender(View view) {
        if (extraEdit1.getText().toString().isEmpty()){

        }else{
            switch (stats){
                case 0:
                    if(!extraEdit3.getText().toString().isEmpty() && !extraEdit2.getText().toString().isEmpty()
                            && !extraEdit1.getText().toString().isEmpty()){
                        Intent intent = new Intent(Intent.ACTION_SENDTO);
                        intent.putExtra(Intent.EXTRA_EMAIL,new String[]{extraEdit3.getText().toString()});//It accepts only arrays so send using string array
                        intent.putExtra(Intent.EXTRA_SUBJECT,extraEdit2.getText().toString() );
                        intent.putExtra(Intent.EXTRA_TEXT,extraEdit1.getText().toString());
                        //intent.setType("message/rfc822");                                               //Used to select any apps
                        intent.setData(Uri.parse("mailto:"));                                       //opens only email apps
                        if (intent.resolveActivity(getPackageManager()) != null){
                            startActivity(intent);
                            extraText1.setVisibility(View.GONE);
                            extraText2.setVisibility(View.GONE);
                            extraText3.setVisibility(View.GONE);
                            extraEditSendBTN.setVisibility(View.GONE);
                            extraEdit1.setText("");
                            extraEdit2.setText("");
                            extraEdit3.setText("");

                        }else {
                            Toast.makeText(getApplicationContext(), "There is no application that supports to send email", Toast.LENGTH_SHORT).show();
                        }
                    }else Toast.makeText(getApplicationContext(), "Please fill all the details !!", Toast.LENGTH_SHORT).show();
                    
                    break;


                case 1:
                    if(!extraEdit3.getText().toString().isEmpty() && !extraEdit2.getText().toString().isEmpty()
                            && !extraEdit1.getText().toString().isEmpty()){

                        Intent intent = new Intent(Intent.ACTION_INSERT_OR_EDIT);
                        intent.setType(ContactsContract.RawContacts.CONTENT_ITEM_TYPE);
                        intent.putExtra(ContactsContract.Intents.Insert.NAME,extraEdit3.getText().toString());
                        intent.putExtra(ContactsContract.Intents.Insert.EMAIL,extraEdit2.getText().toString());
                        intent.putExtra(ContactsContract.Intents.Insert.PHONE,extraEdit1.getText().toString());

                        if(intent.resolveActivity(getPackageManager() )!= null){
                            startActivity(intent);
                            extraText1.setVisibility(View.GONE);
                            extraText2.setVisibility(View.GONE);
                            extraText3.setVisibility(View.GONE);
                            extraEditSendBTN.setVisibility(View.GONE);
                            extraEdit1.setText("");
                            extraEdit2.setText("");
                            extraEdit3.setText("");
                        }else {
                            Toast.makeText(getApplicationContext(), "There is no app that suppors this operation", Toast.LENGTH_SHORT).show();
                        }

                    }else {
                        Toast.makeText(getApplicationContext(), "Please fill all the fields", Toast.LENGTH_SHORT).show();
                    }
                        break;

                case 2:
                    if (!extraEdit2.getText().toString().isEmpty() && !extraEdit1.getText().toString().isEmpty()){

                        Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
                        intent.putExtra(AlarmClock.EXTRA_HOUR, Integer.parseInt(extraEdit2.getText().toString()));
                        intent.putExtra(AlarmClock.EXTRA_MINUTES, Integer.parseInt(extraEdit1.getText().toString()));
                        intent.putExtra(AlarmClock.EXTRA_MESSAGE,"Set alarm for morning walk");

                        if (intent.resolveActivity(getPackageManager()) != null)
                        {    startActivity(intent);

                            timePickerIMG.setVisibility(View.GONE);
                            extraText1.setVisibility(View.GONE);
                            extraText2.setVisibility(View.GONE);
                            extraEditSendBTN.setVisibility(View.GONE);
                            extraEdit1.setText("");
                            extraEdit2.setText("");
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "There is no app for Alarm", Toast.LENGTH_SHORT).show();
                        }
                    }else Toast.makeText(getApplicationContext(), "Please set the time", Toast.LENGTH_SHORT).show();

                            break;


                case 3:
                    if(!extraEdit1.getText().toString().isEmpty() && !extraEdit2.getText().toString().isEmpty()
                        && !extraEdit3.getText().toString().isEmpty()){

                    Intent intent = new Intent(Intent.ACTION_INSERT);
                    intent.setData(CalendarContract.Events.CONTENT_URI);
                    intent.putExtra(CalendarContract.Events.TITLE,extraEdit3.getText().toString());
                    intent.putExtra(CalendarContract.Events.DESCRIPTION,extraEdit2.getText().toString());
                    intent.putExtra(CalendarContract.Events.EVENT_LOCATION,extraEdit1.getText().toString());
                    intent.putExtra(CalendarContract.Events.ALL_DAY, true);
                    intent.putExtra(Intent.EXTRA_EMAIL,"test@gmail.com, tese2@gmail.com");

                    if (intent.resolveActivity(getPackageManager()) != null){
                        startActivity(intent);
                        extraText1.setVisibility(View.GONE);
                        extraText2.setVisibility(View.GONE);
                        extraText3.setVisibility(View.GONE);
                        extraEditSendBTN.setVisibility(View.GONE);
                        extraEdit1.setText("");
                        extraEdit2.setText("");
                        extraEdit3.setText("");
                    }else {
                        Toast.makeText(getApplicationContext(), "There is no Event app ", Toast.LENGTH_SHORT).show();
                    }

                }else {
                    Toast.makeText(getApplicationContext(), "Please fill the details", Toast.LENGTH_SHORT).show();
                }       break;
                case 4:
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    String msg=extraEdit1.getText().toString();
                    sendIntent.putExtra(Intent.EXTRA_TEXT, msg);
                    sendIntent.setType("text/plain");
                    sendIntent.setPackage("com.whatsapp");
                    displayAnswer.setText("please select the contact to send the message");
                    res="please select the contact to send the message";
                    texttospeech();
                    startActivity(sendIntent);
                    extraText1.setVisibility(View.GONE);
                    extraEdit1.setVisibility(View.GONE);
                    extraEditSendBTN.setVisibility(View.GONE);

                    break;
                default:
                    Toast.makeText(getApplicationContext(), "FFFFF", Toast.LENGTH_SHORT).show();


            }
        }



    }

    public void setAlarmTime(View view) {
        calendar = Calendar.getInstance();
        currentHour = calendar.get(Calendar.HOUR_OF_DAY);
        currentMinute = calendar.get(Calendar.MINUTE);

        timePickerDialog = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                extraEdit2.setText(String.format("%02d",hourOfDay));
                extraEdit1.setText(String.format("%02d",minute));
            }
        },currentHour,currentMinute,false);
        timePickerDialog.show();
    }

    public void hint1(View view) {
        inputtext.setText("open Youtube");
        calculate();
    }

    public void hint2(View view) {
        inputtext.setText("send Email");
        calculate();
    }

    public void hint3(View view) {
        inputtext.setText("Set Alarm");
        calculate();
    }

    public void hint4(View view) {
        inputtext.setText("send whatsapp message");
        calculate();
    }

    public void hint5(View view) {
        inputtext.setText("restaurants near me");
        calculate();
    }
}
class Android_Contact {
    public String android_contact_Name = "";
    public String android_contact_TelefonNr = "";
    public int android_contact_ID=0;
}
